package ies.puerto;

public class Ejercicio3 {

    public int verificaNota (int nota){
        int resultado = 0;

        if (nota <= 4.99){
            resultado = 1;
        } else if (nota >= 5 && nota <= 5.99) {
            resultado = 2;
        } else if (nota >= 6 && nota <= 6.99) {
            resultado = 3;
        } else if (nota >= 7 && nota <= 8.99) {
            resultado = 4;
        } else if (nota >= 9 && nota <= 9.99) {
            resultado = 5;
        } else if (nota == 10) {
            resultado = 6;
        }
        return resultado;
    }

    public void clasificaNotas (int nota){
        int notaClasif = verificaNota(nota);
        switch (notaClasif) {
            case 1:
                System.out.println("Suspenso");
                break;

            case 2:
                System.out.println("Aprobado");
                break;

            case 3:
                System.out.println("Bien");
                break;

            case 4:
                System.out.println("Notable");
                break;

            case 5:
                System.out.println("Sobresaliente");
                break;

            case 6:
                System.out.println("Matricula");
                break;

            default:
                System.out.println("La nota del alumno debe estar comprendida entre 0 y 10");
        }
    }

}
