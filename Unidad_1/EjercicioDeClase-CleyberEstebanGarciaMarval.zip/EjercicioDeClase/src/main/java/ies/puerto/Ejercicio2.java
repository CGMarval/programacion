package ies.puerto;

public class Ejercicio2 {
    public void ordenamientoBurbuja (int items []) {
        int limiteSuperior = items.length;
        int temporal;

        boolean intercambiado = false;
        do {
            for (int i = 1; i <= limiteSuperior - 1; i++) {
                if (items[i - 1] > items[i]) {
                    temporal = items[i];
                    items[i] = items[i - 1];
                    items[i - 1] = temporal;
                    intercambiado = true;
                }
                limiteSuperior = limiteSuperior - 1;
            }

        } while (intercambiado);
    }
}
